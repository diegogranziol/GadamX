#!/bin/bash
#SBATCH --nodes=1
#SBATCH --job-name=gn_SGDOPT_VGG16_CIFAR100
#SBATCH --partition=small
#SBATCH --gres=gpu:1
module load python3/anaconda
#SBATCH --mail-type=ALL
#SBATCH --mail-user=diego@robots.ox.ac.uksource activate diegorubin
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00000.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00025.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00050.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00075.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00100.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00125.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00150.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00175.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00200.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00225.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00250.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00275.pt
python3 ../spectrum.py --curvature_matrix=gn   --dataset=CIFAR100 --iters=5 --data_path=../data/ --model=VGG16 --ckpt=/jmain01/home/JAD017/sjr01/dxg49-sjr01/kfac-curvature/out/CIFAR100/VGG16/SGD/seed=1_lr=0.05_mom=0.9_wd=0.0005_numepochs=300/checkpoint-00300.pt
