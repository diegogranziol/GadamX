import torch.nn as nn

__all__ = ['toy_network']