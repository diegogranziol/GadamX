python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=100  --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=50  --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=250  --sub_sample_seed=10


python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=500  --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=1000  --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=2500  --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500 --swag --no_covariance --swag_lr 0.01 --swag_start 25 --sub_sample_seed=10

python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=1
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=2
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=3
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=4
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=5
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=6
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=7
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=8
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=9
python3 run_sgd_smallsample.py --wd=0 --epochs=50 --dataset=MNIST --data_path data/ --lr_init 0.1 --model Logistic --dir out --sub_sample_size=7500  --sub_sample_seed=10
